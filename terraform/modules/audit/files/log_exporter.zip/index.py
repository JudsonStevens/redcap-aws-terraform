import boto3
import json
import os
import time
from datetime import datetime, timedelta, timezone

def handler(event, context):
    logs = boto3.client('logs')
    bucket = os.environ['S3_BUCKET']
    log_groups = json.loads(os.environ['LOG_GROUPS'])

    # Export yesterday's logs
    yesterday = datetime.now(timezone.utc) - timedelta(days=1)
    start = int(datetime(yesterday.year, yesterday.month, yesterday.day, tzinfo=timezone.utc).timestamp() * 1000)
    end = start + (24 * 60 * 60 * 1000)
    date_prefix = yesterday.strftime('%Y/%m/%d')

    results = []
    for log_group in log_groups:
        if not log_group:
            continue
        # Sanitize log group name for S3 prefix
        safe_name = log_group.strip('/').replace('/', '-')
        prefix = f"{safe_name}/{date_prefix}"

        try:
            response = logs.create_export_task(
                logGroupName=log_group,
                fromTime=start,
                to=end,
                destination=bucket,
                destinationPrefix=prefix,
            )
            task_id = response['taskId']
            results.append({"logGroup": log_group, "taskId": task_id, "status": "started"})
            print(f"Export started: {log_group} -> s3://{bucket}/{prefix} (task: {task_id})")
            # CloudWatch allows only one export task at a time per account
            # Wait for it to complete before starting the next
            while True:
                status = logs.describe_export_tasks(taskId=task_id)
                state = status['exportTasks'][0]['status']['code']
                if state in ('COMPLETED', 'FAILED', 'CANCELLED'):
                    results[-1]['status'] = state.lower()
                    print(f"Export {state}: {log_group}")
                    break
                time.sleep(5)
        except Exception as e:
            results.append({"logGroup": log_group, "error": str(e)})
            print(f"Export failed for {log_group}: {e}")

    return {"exports": results}
